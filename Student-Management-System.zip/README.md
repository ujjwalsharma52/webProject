# 🎓 Student Management System (C++)

A basic console-based Student Management System built using C++. This program allows users to:

- Add student records
- View all student records
- Store data in a binary file (`students.txt`)

## 🛠️ Features

- Object-Oriented Programming
- File handling using binary files
- Simple menu-based navigation

## 💻 How to Run

1. Compile the program:
   ```
   g++ main.cpp -o student
   ```

2. Run the executable:
   ```
   ./student     // Linux or Mac
   student.exe   // Windows (double click also works)
   ```

3. Use the menu to manage students.

## 📁 Output Example

```
===== Student Management Menu =====
1. Add Student
2. View All Students
3. Exit
Enter your choice:
```

## 📌 Note

- File `students.txt` will be automatically created in the same folder.
- You can open it only through code (it's in binary format).
